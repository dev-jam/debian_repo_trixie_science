
__title__ = 'pylink'
__description__ = 'Python module for interfacing SR Research EyeLink eye trackers'
__url__ = 'https://www.sr-research.com/support'
__version__ = '2.2.183.0'
__author__ = 'SR Research Ltd'
__author_email__ = 'support@sr-research.com'
__license__ = 'SR Research Ltd.'
__copyright__ = 'Copyright 2025 SR Research Ltd.'
