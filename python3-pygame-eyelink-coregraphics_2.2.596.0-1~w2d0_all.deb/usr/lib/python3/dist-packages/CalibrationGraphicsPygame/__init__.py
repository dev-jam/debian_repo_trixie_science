import importlib.metadata

# Pulls the version directly from your pyproject.toml
__version__ = importlib.metadata.version("pygame-eyelink-coregraphics")
_last_updated = '13/04/2026' # Update this to your desired date

# Expose the main class at the package level so users can just do:
# from CalibrationGraphicsPygame import CalibrationGraphics
from .CalibrationGraphicsPygame import CalibrationGraphics