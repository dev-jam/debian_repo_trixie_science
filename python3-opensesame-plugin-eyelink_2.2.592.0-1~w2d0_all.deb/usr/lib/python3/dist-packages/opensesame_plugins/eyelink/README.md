# EyeLink Plugin for OpenSesame 4 
# SR Research 2026
# support@sr-research.com
