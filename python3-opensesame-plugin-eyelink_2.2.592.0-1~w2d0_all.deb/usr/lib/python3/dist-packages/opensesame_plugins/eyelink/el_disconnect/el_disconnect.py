# -*- coding:utf-8 -*-
#
# Copyright (c) 1996-2024, SR Research Ltd., All Rights Reserved
#
# For use by SR Research licencees only. Redistribution and use in source
# and binary forms, with or without modification, are NOT permitted.
#
# Redistributions in binary form must reproduce the above copyright
# notice, this list of conditions and the following disclaimer in
# the documentation and/or other materials provided with the distribution.
#
# Neither name of SR Research Ltd nor the name of contributors may be used
# to endorse or promote products derived from this software without
# specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS
# IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# 2024
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or (at
# your option) any later version.
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 51
# Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

from libopensesame.py3compat import *
from libopensesame.item import Item
from libqtopensesame.items.qtautoplugin import QtAutoPlugin
from openexp.canvas import Canvas

import pylink
import os
import sys
import traceback  # Added for robust error logging

class ElDisconnect(Item):
    # Provide an informative description for your plug-in.
    description = u'Terminate the link to the EyeLink tracker.'

    def reset(self):
        """ desc:Resets plug-in to initial values """

        # Here we provide default values for the variables that are specified
        # in __init__.py
        pass

    def prepare(self):

        """The preparation phase of the plug-in goes here."""

        # Call the parent constructor.
        Item.prepare(self)
        self.data_transfer_canvas = Canvas(self.experiment)
        self.data_transfer_canvas.clear()
        self.data_transfer_canvas.text('Retrieving EDF data file from the EyeLink Host PC...')

    def run(self):
        """The run phase of the plug-in goes here."""

        if self.experiment.dummy_mode is not True:
            el_tracker = self.experiment.eyelink
            
            if el_tracker.isConnected():
                # 1. Terminate the current trial first if it is still recording
                if el_tracker.isRecording() == pylink.TRIAL_OK:
                    el_tracker.stopRecording()
                    
                # 2. Put tracker in Offline mode
                el_tracker.setOfflineMode()
                pylink.pumpDelay(100)  # <-- DELAY 1: Let the tracker switch modes
                
                # 3. Clear the Host PC screen and wait 500 ms for the buffer to flush
                el_tracker.sendCommand('clear_screen 0')
                pylink.pumpDelay(500)  # <-- DELAY 2: CRITICAL buffer flush time
                
                # 4. Close the edf data file on the Host
                el_tracker.closeDataFile()
                pylink.pumpDelay(100)  # <-- DELAY 3: Brief pause after closing the file
                
                # 5. Show the "retrieving EDF data file ..." message
                self.data_transfer_canvas.show()
                
                # 6. Construct clean paths
                source_file = self.experiment.edf_data_file
                dest_folder = self.experiment.edf_data_folder
                
                clean_filename = source_file.strip()
                if not clean_filename.upper().endswith('.EDF'):
                    clean_filename += '.EDF'
                
                # 7. Download the files using OS-specific logic
                try:
                    if not os.path.exists(dest_folder):
                        os.makedirs(dest_folder, exist_ok=True)
                    
                    if sys.platform == 'win32':
                        # Windows: Use the silent CWD Bypass
                        original_cwd = os.getcwd() 
                        try:
                            os.chdir(dest_folder)
                            # Grab the EDF (and automatically the EVF companion)
                            file_size = el_tracker.receiveDataFile(source_file, clean_filename, 6)
                        finally:
                            # ALWAYS switch back to the original directory
                            os.chdir(original_cwd)
                    else:
                        # macOS/Linux: Safe to use POSIX absolute paths natively
                        dest_path = os.path.join(dest_folder, clean_filename)
                        file_size = el_tracker.receiveDataFile(source_file, dest_path, 6)
                        
                    # Print success message regardless of platform
                    if file_size is not None and file_size > 0:
                        print(f"File saved to: {os.path.join(dest_folder, clean_filename)}")
                        
                except RuntimeError:
                    pass
                except Exception:
                    pass

                # 8. Wait for message to be read by user, then close connection
                pylink.pumpDelay(1500)  # <-- DELAY 4: Keep the transfer message on screen
                el_tracker.close()
        else:
            pass


class QtElDisconnect(ElDisconnect, QtAutoPlugin):

    """ this class handles the GUI aspect of the plug-in. By using qtautoplugin, we
    usually need to do hardly anything, because the GUI is defined in init. """

    def __init__(self, name, experiment, script=None):

        # We don't need to do anything here, except call the parent
        # constructors.
        ElDisconnect.__init__(self, name, experiment, script)
        QtAutoPlugin.__init__(self, __file__)