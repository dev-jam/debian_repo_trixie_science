# -*- coding:utf-8 -*-
#
# Copyright (c) 1996-2024, SR Research Ltd., All Rights Reserved
#
# For use by SR Research licencees only. Redistribution and use in source
# and binary forms, with or without modification, are NOT permitted.
#
# Redistributions in binary form must reproduce the above copyright
# notice, this list of conditions and the following disclaimer in
# the documentation and/or other materials provided with the distribution.
#
# Neither name of SR Research Ltd nor the name of contributors may be used
# to endorse or promote products derived from this software without
# specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS
# IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# 2024
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or (at
# your option) any later version.
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 51
# Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

# Import Python 3 compatibility functions
from libopensesame.py3compat import *
from libopensesame.item import Item
from libqtopensesame.items.qtautoplugin import QtAutoPlugin
from EyeLinkCoreGraphicsOpensesame import EyeLinkCoreGraphicsOpensesame
from openexp.canvas import Canvas
import pylink


class ElDriftCheck(Item):
    # Provide an informative description for your plug-in.
    description = u'Perform drift-correction/check'

    def reset(self):

        """ desc: Resets plug-in to initial values. """

        # Here we provide default values for the variables that are specified
        # in __init__.py
        self.var.el_drift_tar_x = u'%d' % 0
        self.var.el_drift_tar_y = u'%d' % 0
        self.var.el_allow_setup = u'yes'
        self.var.el_dc_target_type = u'SameAsCalibration'
        self.var.el_dc_target_file = u''

    def prepare(self):

        """The preparation phase of the plug-in goes here."""

        # Call the parent constructor.
        Item.prepare(self)

        # prepare the drift-correction display
        self.dc_canvas = Canvas(self.experiment)

    def run(self):

        """The run phase of the plug-in goes here."""

        if self.experiment.dummy_mode is False:
            print('connected to tracker')
            # decide if you the drawing routine in the CoreGraphics to draw the drift
            # correction target, 1=yes, 0=no
            target_sameAsCalibration = 1
            if self.var.el_dc_target_type == u'Image':
                target_sameAsCalibration = 0
            
            # load image as calibration target
            if self.var.el_dc_target_type == u'Image':
                target_img = self.experiment.pool[self.var.el_dc_target_file]
                self.dc_canvas.image(target_img, True, x=int(self.var.el_drift_tar_x),
                                     y=int(self.var.el_drift_tar_y))
                
            # decide if allow setup
            allow_setup = 0
            if self.var.el_allow_setup == u'yes':
                allow_setup = 1

            # Disable pause Esc key temporarily
            original_pause = self.experiment.pause
            
            def custom_pause_override():
                # Pygame Event Blackhole Fix:
                # We only inject the remote Esc key for Pygame ('legacy' or 'xpyriment').
                # PsychoPy handles local keyboard hooks natively without eating them, 
                # so sending this in PsychoPy would cause a "Double Esc" glitch!
                if getattr(self.experiment.var, 'canvas_backend', '') != 'psycho':
                    try:
                        self.experiment.eyelink.sendKeybutton(27, 0, 1)
                    except Exception:
                        pass
                    
            self.experiment.pause = custom_pause_override

            def enforce_global_mouse_state():
                """Restores or aggressively hides the mouse based on the global state."""
                # Default to False (hide) if el_connect hasn't run or failed to capture
                should_be_visible = getattr(self.experiment, '_el_original_mouse_visible', False)
                
                # 1. OpenSesame Native Standard
                try:
                    from openexp.mouse import mouse
                    my_mouse = mouse(self.experiment)
                    my_mouse.show_cursor(should_be_visible)
                except Exception:
                    pass

                # 2. Aggressive Backend Enforcement
                backend = getattr(self.experiment.var, 'canvas_backend', '')
                if backend == 'psycho':
                    try:
                        if hasattr(self.experiment, 'window'):
                            self.experiment.window.setMouseVisible(should_be_visible)
                    except Exception:
                        pass
                elif backend in ['legacy', 'xpyriment']:
                    try:
                        import pygame
                        pygame.mouse.set_visible(should_be_visible)
                    except Exception:
                        pass

            try:
                while True:
                    # Draw the canvas inside the loop! 
                    # When returning from Camera Setup, the screen will be blank. 
                    # This ensures the custom image redraws before the next drift check.
                    if self.var.el_dc_target_type == u'Image':
                        self.dc_canvas.show()

                    try:
                        err = self.experiment.eyelink.doDriftCorrect(
                            int(self.var.el_drift_tar_x+self.dc_canvas.width/2.0),
                            int(self.var.el_drift_tar_y+self.dc_canvas.height/2.0),
                            target_sameAsCalibration, allow_setup)
                        
                        if err == 0:  
                            # break following a successful drift-check
                            break
                        elif err == 27:
                            # Esc was pressed. Launch Camera Setup!
                            self.experiment.eyelink.doTrackerSetup()
                            # Once Camera Setup is exited, we do NOT break.
                            # The while loop restarts, redraws the target, and forces 
                            # the user to pass a drift check before the trial begins.
                    except Exception:
                        pass
            finally:
                # =================================================================
                # NEW: Restore the original OpenSesame Esc pause function
                # The 'finally' block ensures this runs even if setup crashes
                # =================================================================
                self.experiment.pause = original_pause
                
                # Apply our aggressive global mouse state logic
                enforce_global_mouse_state()
        else:
            pass
		

class QtElDriftCheck(ElDriftCheck, QtAutoPlugin):

    """
    This class handles the GUI aspect of the plug-in. By using qtautoplugin, we
    usually need to do hardly anything, because the GUI is defined in info.json.
    """

    def __init__(self, name, experiment, script=None):
        # We don't need to do anything here, except call the parent
        # constructors.
        ElDriftCheck.__init__(self, name, experiment, script)
        QtAutoPlugin.__init__(self, __file__)

    def apply_edit_changes(self):
        # Applies the controls.
        if not QtAutoPlugin.apply_edit_changes(self) or self.lock:
            return False
        self.custom_interactions()

    def edit_widget(self):
        # Refreshes the controls.
        if self.lock:
            return
        self.lock = True
        w = QtAutoPlugin.edit_widget(self)
        self.custom_interactions()
        self.lock = False
        return w

    def custom_interactions(self):
        ''' all necessary option changes for the tracker.'''

        if self.combobox_el_dc_target_type.currentIndex() == 0:
            self.filepool_el_dc_target_file.setEnabled(False)
        else:
            self.filepool_el_dc_target_file.setEnabled(True)
