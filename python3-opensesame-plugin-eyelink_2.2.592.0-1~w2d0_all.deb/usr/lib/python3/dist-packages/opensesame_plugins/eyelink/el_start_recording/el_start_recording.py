# -*- coding:utf-8 -*-
#
# Copyright (c) 1996-2026, SR Research Ltd., All Rights Reserved
#
# For use by SR Research licencees only. Redistribution and use in source
# and binary forms, with or without modification, are NOT permitted.
#
# Redistributions in binary form must reproduce the above copyright
# notice, this list of conditions and the following disclaimer in
# the documentation and/or other materials provided with the distribution.
#
# Neither name of SR Research Ltd nor the name of contributors may be used
# to endorse or promote products derived from this software without
# specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS
# IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# 2026
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or (at
# your option) any later version.
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 51
# Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

# -*- coding:utf-8 -*-
#
# Copyright (c) 1996-2026, SR Research Ltd., All Rights Reserved
# ... [Keep your standard copyright headers here] ...

import os
import time
import tempfile
import pylink
import pygame
from libopensesame.py3compat import *
from libopensesame.item import Item
from libqtopensesame.items.qtautoplugin import QtAutoPlugin


class ElStartRecording(Item):
    description = 'Start data recording with Multi-Backend Host PC Snapshot'

    def __init__(self, name, experiment, string=None):
        super().__init__(name, experiment, string)

    def reset(self):
        self.var.el_link_data_events = 'yes'
        self.var.el_link_data_samples = 'yes'
        self.var.el_recording_status_msg = ''
        self.var.el_host_target_item = ''

    def run(self):
        link_events = 0
        link_samples = 0
        file_events = 1
        file_samples = 1
        if self.var.el_link_data_events == u'yes':
            link_events = 1
        if self.var.el_link_data_samples == u'yes':
            link_samples = 1

        if self.experiment.dummy_mode is False:
            el = self.experiment.eyelink
            win = self.experiment.window
            backend = self.experiment.var.canvas_backend
            w = int(self.experiment.var.width)
            h = int(self.experiment.var.height)
            
            target_name = self.var.get('el_host_target_item', '').strip()
            
            # --- IMAGE CAPTURE AND TRANSFER ---
            if target_name and target_name in self.experiment.items:
                target_item = self.experiment.items[target_name]
                
                if hasattr(target_item, 'canvas'):
                    # Use OS temp directory and .bmp to bypass slow PNG compression
                    temp_dir = tempfile.gettempdir()
                    timestamp = int(time.time() * 1000)
                    temp_filename = f"host_snap_{timestamp}.bmp"
                    temp_path = os.path.join(temp_dir, temp_filename)
                    
                    capture_success = False

                    try:
                        # --- PSYCHOPY ---
                        if backend == 'psycho':
                            if hasattr(target_item.canvas, '_elements'):
                                for elem_name, elem in target_item.canvas._elements.items():
                                    if hasattr(elem, 'draw'): elem.draw()
                                    elif hasattr(elem, '_stim') and hasattr(elem._stim, 'draw'): elem._stim.draw()
                            
                            win.getMovieFrame(buffer='back')
                            win.saveMovieFrames(temp_path)
                            win.movieFrames = []

                            # --- macOS RETINA / HIGH-DPI FIX VIA PIL ---
                            if os.path.exists(temp_path):
                                try:
                                    from PIL import Image
                                    with Image.open(temp_path) as img:
                                        img_w, img_h = img.size
                                        
                                        # 1. Crush Retina physical pixels back down to OpenSesame logical pixels
                                        if img_w != w or img_h != h:
                                            img = img.resize((w, h), Image.LANCZOS)
                                        
                                        # 2. Force strict 24-bit depth (strips alpha channel/padding for EyeLink)
                                        img = img.convert('RGB')
                                        img.save(temp_path, format='BMP')
                                except Exception as scale_err:
                                    print(f"[EyeLink Debug] Retina PIL scaling failed: {scale_err}")
                                    
                            capture_success = True
                            
                        # --- PYGAME / LEGACY ---
                        elif backend in ['pygame', 'legacy']:
                            import pygame
                            target_item.canvas.prepare()
                            if hasattr(target_item.canvas, 'surface'):
                                pygame.image.save(target_item.canvas.surface, temp_path)
                                capture_success = True

                        # --- EXPYRIMENT (Direct Pool Blit) ---
                        elif backend == 'xpyriment':
                            snap_surf = pygame.Surface((w, h))
                            
                            bg_col = self.experiment.var.get('background', 'black')
                            try:
                                snap_surf.fill(pygame.Color(bg_col))
                            except:
                                snap_surf.fill((190, 190, 190))

                            target_item.canvas.prepare()
                            
                            elements = getattr(target_item.canvas, '_elements', {})
                            for name, elem in elements.items():
                                if name == '__background__':
                                    continue
                                
                                s = None
                                stim = getattr(elem, '_stim', elem)
                                for attr in ['surface', '_surface', 'picture', '_picture']:
                                    val = getattr(stim, attr, None)
                                    if isinstance(val, pygame.surface.Surface):
                                        s = val; break
                                
                                if s is None:
                                    img_file = getattr(elem, 'fname', getattr(elem, 'file', getattr(elem, 'path', None)))
                                    
                                    if not img_file:
                                        try: img_file = self.experiment.var.get('image')
                                        except: img_file = None

                                    if img_file and img_file in self.experiment.pool:
                                        try:
                                            s = pygame.image.load(self.experiment.pool[img_file])
                                        except:
                                            pass
                                
                                if s:
                                    ex = getattr(elem, 'x', 0)
                                    ey = getattr(elem, 'y', 0)
                                    sw, sh = s.get_size()
                                    bx = int(ex + (w / 2) - (sw / 2))
                                    by = int(ey + (h / 2) - (sh / 2))
                                    snap_surf.blit(s, (bx, by))

                            pygame.image.save(snap_surf, temp_path)
                            capture_success = True

                    except Exception as e:
                        print(f"[EyeLink Debug] ERROR during {backend} capture: {e}")

                    # --- TRANSFER ---
                    if capture_success and os.path.exists(temp_path):
                        try:
                            # Switch to offline mode immediately before transfer
                            el.setOfflineMode()
                            pylink.pumpDelay(50)
                            el.imageBackdrop(temp_path, 0, 0, 0, 0, 0, 0, pylink.BX_MAXCONTRAST)
                        except Exception as e:
                            print(f"[EyeLink] imageBackdrop failed: {e}")
                        finally:
                            # Immediately clean up the file, leaving nothing behind
                            try:
                                os.remove(temp_path)
                            except Exception as e:
                                print(f"[EyeLink Debug] Failed to remove temp file: {e}")

            # --- START RECORDING ---
            el.sendMessage('TRIALID')
            if self.var.el_recording_status_msg:
                el.sendCommand("record_status_message '%s'" % self.var.el_recording_status_msg)
            el.startRecording(1, 1, link_samples, link_events)
            pylink.pumpDelay(100)
            
        print(self.var.el_recording_status_msg)


class QtElStartRecording(ElStartRecording, QtAutoPlugin):
    def __init__(self, name, experiment, script=None):
        ElStartRecording.__init__(self, name, experiment, script)
        QtAutoPlugin.__init__(self, __file__)

    def init_edit_widget(self):
        super().init_edit_widget()