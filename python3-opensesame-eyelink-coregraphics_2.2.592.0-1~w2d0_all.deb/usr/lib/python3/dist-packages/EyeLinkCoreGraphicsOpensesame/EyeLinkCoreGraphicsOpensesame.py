# -*- coding:utf-8 -*-
#
# Copyright (c) 1996-2026, SR Research Ltd., All Rights Reserved
#
# For use by SR Research licencees only. Redistribution and use in source
# and binary forms, with or without modification, are NOT permitted.
#
# Redistributions in binary form must reproduce the above copyright
# notice, this list of conditions and the following disclaimer in
# the documentation and/or other materials provided with the distribution.
#
# Neither name of SR Research Ltd nor the name of contributors may be used
# to endorse or promote products derived from this software without
# specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS
# IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# 2026 SR Research
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or (at
# your option) any later version.
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 51
# Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

from __future__ import print_function
from openexp.canvas import Canvas
from openexp.keyboard import Keyboard
from openexp.mouse import Mouse
from PIL import Image, ImageDraw
from moviepy.video.io.VideoFileClip import VideoFileClip
import numpy
import array
import string
import pylink
import os.path
import tempfile
import time
import pygame
import platform

class EyeLinkCoreGraphicsOpensesame(pylink.EyeLinkCustomDisplay):
    def __init__(self, experiment, tracker):
        pylink.EyeLinkCustomDisplay.__init__(self)
        self.experiment = experiment
        self.display = Canvas(self.experiment)
        self.keyboard = Keyboard(self.experiment, timeout=0)
        self.mouse = Mouse(self.experiment, timeout=1)

        # Check disable flag early
        self._disable_audio = getattr(self.experiment, 'disable_el_audio', False)

        self.__target_beep__ = None
        self.__target_beep__done__ = None
        self.__target_beep__error__ = None

        if not self._disable_audio:
            try:
                # Safely boot Pygame mixer if it isn't already running
                if pygame.mixer.get_init() is None:
                    pygame.mixer.init()
                    
                plugin_dir = os.path.dirname(os.path.abspath(__file__))
                self.__target_beep__ = pygame.mixer.Sound(os.path.join(plugin_dir, 'qbeep.wav'))
                self.__target_beep__done__ = pygame.mixer.Sound(os.path.join(plugin_dir, 'type.wav'))
                self.__target_beep__error__ = pygame.mixer.Sound(os.path.join(plugin_dir, 'error.wav'))
            except Exception as e:
                print(f"DEBUG ERROR: Failed to load pygame audio: {e}")
                # If audio fails (e.g., Linux root user permission issues), fail gracefully
                self._disable_audio = True
                
        # Trackers to prevent the Host PC from spamming audio commands
        self._allow_target_beep = False
        self._last_target_x = -32768
        self._last_target_y = -32768

        self.buffer_type = 'I'
        self.imagebuffer = array.array(self.buffer_type)
        self.pal = None
        self.cam_img = os.path.join(tempfile.gettempdir(), '_el_cam_.bmp')
        self.vid_img = os.path.join(tempfile.gettempdir(), '_vid_img.bmp')
        self._img_title_ = ''
        self.display_width = 0
        self.display_height = 0

        self.scale_x = 1.0
        self.scale_y = 1.0
        
        backend = getattr(self.experiment.var, 'canvas_backend', '')
        if backend == 'psycho' and hasattr(self.experiment, 'window'):
            win = self.experiment.window
            phys_w = float(win.size[0])
            phys_h = float(win.size[1])
            req_w = float(self.display.width)
            req_h = float(self.display.height)
            
            # Calculate the exact distortion ratio forced by PsychoPy
            if phys_w != req_w:
                self.scale_x = phys_w / req_w
            if phys_h != req_h:
                self.scale_y = phys_h / req_h


        # initialize the mediadecoder if using animated calibration targets (videos)
        if self.experiment.cal_target_type == 'image':
            self.cal_target_img = self.experiment.cal_target_img

        if self.experiment.cal_target_type == 'video':
            self.cal_target_vid = self.experiment.cal_target_vid
            self.vid = VideoFileClip(self.cal_target_vid, audio=0)
            self.vid_start_time = 0.0
            self.vid_current_time = 0.0
            self.vid_X = -32768
            self.vid_Y = -32768
            self.vid_show = False

        self.last_mouse_state = -1

        # set a couple tracker parameters
        self.tracker = tracker
        self.tracker.setOfflineMode()
        # screen resolution
        self.tracker.sendCommand("screen_pixel_coords = 0 0 %d %d" % (self.display.width-1, self.display.height-1))
        self.tracker_version = self.tracker.getTrackerVersion()
        if self.tracker_version >= 3:
            self.tracker.sendCommand("enable_search_limits=YES")
            self.tracker.sendCommand("track_search_limits=YES")
            self.tracker.sendCommand("autothreshold_click=YES")
            self.tracker.sendCommand("autothreshold_repeat=YES")
            self.tracker.sendCommand("enable_camera_position_detect=YES")

    def get_frame_img(self, mov, frame_time):
        ''' this helps to get the current frame of a video'''
        numpy_frame = mov.get_frame(frame_time)
        img = Image.fromarray(numpy_frame)
        img.save(self.vid_img)

    def cal_instructions(self):
        ''' just show the calibration instruction on screen'''

        x = -self.display.width/2+20
        y = -self.display.height/2+20
        y_span = 22
        self.display.text('Enter: Show/hide camera image', False, x, y, font_size=20)
        self.display.text('Left/Right: Switch camera view', False, x, y+y_span, font_size=20)
        self.display.text('C: Calibration', False, x, y+y_span*2, font_size=20)
        self.display.text('V: Validation', False, x, y+y_span*3, font_size=20)
        self.display.text('O: Start Recording', False, x, y+y_span*4, font_size=20)
        self.display.text('+=/-: CR threshold', False, x, y+y_span*5, font_size=20)
        self.display.text('Up/Down: Pupil threshold', False, x, y+y_span*6, font_size=20)
        self.display.text('F1: F1 = EyeLink Hotkey-ESCAPE', False, x, y+y_span*7, font_size=20)

    def setup_cal_display(self):
        ''' Set up the calibration display before entering the calibration/validation routine'''

        self.display.clear()
        #self.cal_instructions()
        self.display.show()

    def clear_cal_display(self):
        ''' Clear the calibration display'''

        self.display.clear()
        self.display.show()

    def exit_cal_display(self):
        ''' Exit the calibration/validation routine'''

        self.display.clear()
        self.display.show()

    def record_abort_hide(self):
        ''' This function is called if aborted'''

        pass

    def erase_cal_target(self):
        ''' Erase the calibration/validation & drift-check target'''
        self.vid_show = False
        self.display.clear()
        self.display.show()

    def draw_cal_target(self, x, y):
        ''' Draw the calibration/validation & drift-check target'''

        if abs(x - self._last_target_x) > 5 or abs(y - self._last_target_y) > 5:
            self._allow_target_beep = True
            self._last_target_x = x
            self._last_target_y = y

        self.display.clear()
        self.mouse.show_cursor(show=False)
        
        raw_x = x - self.display.width / 2.0
        raw_y = y - self.display.height / 2.0

        safe_scale_x = getattr(self, 'scale_x', 1.0)
        safe_scale_y = getattr(self, 'scale_y', 1.0)
        
        tarX = raw_x * safe_scale_x
        tarY = raw_y * safe_scale_y

        backend = getattr(self.experiment.var, 'canvas_backend', '')
        
        backend = getattr(self.experiment.var, 'canvas_backend', '')
        if backend == 'psycho' and hasattr(self.experiment, 'window'):
            if getattr(self.experiment.window, 'useRetina', False):
                tarX = tarX / 2.0
                tarY = tarY / 2.0

        if self.experiment.cal_target_type == 'default':  
            self.display.fixdot(tarX, tarY, style='medium-open')
        elif self.experiment.cal_target_type == 'image':  
            self.display.image(self.cal_target_img, True, tarX, tarY)
        else:      
            self.vid_start_time = time.time()
            self.get_frame_img(self.vid, self.vid_current_time)
            self.display.image(self.vid_img, True, tarX, tarY)
            self.vid_X = tarX
            self.vid_Y = tarY
            self.vid_show = True

        self.display.show()

    def play_beep(self, beepid):
        ''' Play a sound during calibration/drift correct using Pygame. '''
        if self._disable_audio:
            return

        try:
            # 1. TARGET BEEPS (Locked to physical target movement)
            if beepid in [pylink.CAL_TARG_BEEP, pylink.DC_TARG_BEEP]:
                if self._allow_target_beep:  
                    if self.__target_beep__: 
                        self.__target_beep__.play()
                    self._allow_target_beep = False 
                    
            # 2. ERROR BEEPS
            elif beepid in [pylink.CAL_ERR_BEEP, pylink.DC_ERR_BEEP]:
                if self.__target_beep__error__: 
                    self.__target_beep__error__.play()
                    
            # 3. GOOD BEEPS
            elif beepid in [pylink.CAL_GOOD_BEEP, pylink.DC_GOOD_BEEP]:
                if self.__target_beep__done__: 
                    self.__target_beep__done__.play()
                    
        except Exception as e:
            print(f"DEBUG ERROR: Error playing calibrartion audio: {e}")

    def getColorFromIndex(self, colorindex):
        
        if colorindex == pylink.CR_HAIR_COLOR:
            return (255, 255, 255)
        elif colorindex == pylink.PUPIL_HAIR_COLOR:
            return (255, 255, 255)
        elif colorindex == pylink.PUPIL_BOX_COLOR:
            return (0, 255, 0)
        elif colorindex == pylink.SEARCH_LIMIT_BOX_COLOR:
            return (255, 0, 0)
        elif colorindex == pylink.MOUSE_CURSOR_COLOR:
            return (255, 0, 0)
        elif colorindex == pylink. SCREEN_OVERLAY_COLOR_1:
            return (0, 255, 0)
        else:
            return (128,128,128)

    def draw_line(self, x1, y1, x2, y2, colorindex):
        ''' Draw a line. This is used for drawing crosshairs/squares'''

        color = self.getColorFromIndex(colorindex)

        if self.size[0] > 192:
            # Use raw camera dimensions so overlays don't stretch into the text padding
            w = getattr(self, 'cam_physical_width', self.__img__.im.size[0])
            h = getattr(self, 'cam_physical_height', self.__img__.im.size[1])
            
            x1 = int((float(x1) / self.base_width) * w)
            x2 = int((float(x2) / self.base_width) * w)
            y1 = int((float(y1) / self.base_height) * h)
            y2 = int((float(y2) / self.base_height) * h)
            
        # draw the line
        if not True in [x <0 for x in [x1, x2, y1, y2]]:
            self.__img__.line([(x1, y1), (x2, y2)], color)


    def draw_lozenge(self, x, y, width, height, colorindex):
        ''' draw a lozenge to show the defined search limits
        (x,y) is top-left corner of the bounding box'''

        color = self.getColorFromIndex(colorindex)
        
        if self.size[0] > 192:
            # Use raw camera dimensions so ellipses don't stretch into the text padding
            w = getattr(self, 'cam_physical_width', self.__img__.im.size[0])
            h = getattr(self, 'cam_physical_height', self.__img__.im.size[1])
            
            x = int((float(x) / self.base_width) * w)
            y = int((float(y) / self.base_height) * h)
            width = int((float(width) / self.base_width) * w)
            height = int((float(height) / self.base_height) * h)
    
        if width > height:
            rad = int(height / 2.)
            if rad == 0:
                return
            else:
                self.__img__.line([(x + rad, y), (x + width - rad, y)], color, 1)
                self.__img__.line([(x + rad, y + height), (x + width - rad, y + height)], color, 1)
                self.__img__.arc([x, y, x + rad*2, y + rad*2], 90, 270, color, 1)
                self.__img__.arc([x + width - rad*2, y, x + width, y + height], 270, 90, color, 1)
        else:
            rad = int(width / 2.)
            if rad == 0:
                return
            else:
                self.__img__.line([(x, y + rad), (x, y + height - rad)], color, 1)
                self.__img__.line([(x + width, y + rad), (x + width, y + height - rad)], color, 1)
                self.__img__.arc([x, y, x + rad*2, y + rad*2], 180, 360, color, 1)
                self.__img__.arc([x, y + height-rad*2, x + rad*2, y + height], 0, 180, color, 1)
            

    def get_mouse_state(self):
        '''Get the current mouse position and status, converted for pylink.'''
        
        button_code, pos, timestamp = self.mouse.get_pressed()
        (mx, my), timestamp_pos = self.mouse.get_pos()

        pylink_button_state = 1 if button_code == 1 else 0
        final_x, final_y = -1, -1
        
        if hasattr(self, 'cam_padded_height'):
            # The top edge of the whole image includes the padding!
            img_top_edge_y = -self.cam_padded_height / 2.0
            img_left_edge_x = -self.cam_physical_width / 2.0

            relative_x = mx - img_left_edge_x
            relative_y = my - img_top_edge_y

            # Scale clicks strictly relative to the camera feed (ignoring text padding)
            orig_width = self.size[0]
            orig_height = self.size[1]
            
            final_x = relative_x * (orig_width / float(self.cam_physical_width))
            final_y = relative_y * (orig_height / float(self.cam_physical_height))

        return ((int(final_x), int(final_y)), pylink_button_state)

    def get_input_key(self):

        # update the current video frame if animation calibration target is used
        if self.experiment.cal_target_type == 'video':
            if self.vid_show:
                self.vid_current_time = time.time() - self.vid_start_time
                if self.vid_current_time < self.vid.duration:
                    self.get_frame_img(self.vid, self.vid_current_time)
                    self.display.image(self.vid_img, True,self.vid_X, self.vid_Y)
                    self.display.show()
                else:
                    self.vid_start_time = time.time()
                
        ky=[]
        try:
            keycode, keyTime = self.keyboard.get_key()
            modifier = self.keyboard.get_mods()
            if keycode   in ['f1', 'F1']: k = pylink.ESC_KEY #pylink.F1_KEY
            elif keycode in ['f2', 'F2']: k = pylink.F2_KEY
            elif keycode in ['f3', 'F3']: k = pylink.F3_KEY
            elif keycode in ['f4', 'F4']: k = pylink.F4_KEY
            elif keycode in ['f5', 'F5']: k = pylink.F5_KEY
            elif keycode in ['f6', 'F6']: k = pylink.F6_KEY
            elif keycode in ['f7', 'F7']: k = pylink.F7_KEY
            elif keycode in ['f8', 'F8']: k = pylink.F8_KEY
            elif keycode in ['f9', 'F9']: k = pylink.F9_KEY
            elif keycode in ['f10','F10']: k = pylink.F10_KEY
            elif keycode in ['pageup','PAGEUP','PAGE UP']: k = pylink.PAGE_UP
            elif keycode in ['pagedown','PAGEDOWN', 'PAGE DOWN']: k = pylink.PAGE_DOWN
            elif keycode in ['up','UP']: k = pylink.CURS_UP
            elif keycode in ['down','DOWN']: k = pylink.CURS_DOWN
            elif keycode in ['left','LEFT']: k = pylink.CURS_LEFT
            elif keycode in ['right','RIGHT']: k = pylink.CURS_RIGHT
            elif keycode in ['backspace','BACKSPACE']: k = ord('\b')
            elif keycode in ['return','RETURN']: k = pylink.ENTER_KEY
            elif keycode in ['space','SPACE']: k = ord(' ')
            elif keycode in ['escape','ESCAPE']: k = pylink.ESC_KEY
            elif keycode in ['tab','TAB']: k = ord('\t')
            elif (len(keycode)==1) and (keycode in string.ascii_letters):
                if keycode in ['q', 'Q']:
                    self.experiment.end()
                else:
                    k = ord(keycode)
            else: k = 0

            # plus/equal & minux signs for CR adjustment
            if keycode in ['num_add', 'NUM_ADD', 'EQUAL', 'equal','=']: k = ord('+')
            if keycode in ['num_subtract', 'NUM_SUBTRACT','MINUS', 'minus','-']: k = ord('-')
            
            if 'alt' in modifier:
                mod = 256
            elif 'ctrl' in modifier:
                mod = 64
            elif 'shift' in modifier:
                mod = 1
            else:
                mod = 0
            ky.append(pylink.KeyInput(k, mod))
        except:
            ky.append(pylink.KeyInput(0, 0))
        return ky

    def exit_image_display(self):
        '''Clear the camera image'''      
        self.clear_cal_display()
        self.mouse.show_cursor(show=True)

    def alert_printf(self,msg):
        '''Print error messages.'''
        print("Error: " + msg)

    def setup_image_display(self, width, height):
        ''' set up the camera image, for newer APIs, the size is 384 x 320 pixels'''

        self.last_mouse_state = -1
        self.mouse.show_cursor(show=False)
        
        self.size = (width, height)
        self.vid_show = False

        return 1

    def image_title(self, text):
        '''Draw title text below the camera image'''

        self._img_title_=text
        text_y_pos = int(self.size[1] / 2.0) + 20 # Same padding as in draw_image_line
        self.display.text(self._img_title_, True, x=int(0), y=text_y_pos, font_size=20)
        
    
    def draw_image_line(self, width, line, totlines, buff):
        '''Display image pixel by pixel, line by line'''
        
        # --- 1. LIGHTNING FAST NUMPY BYPASS ---
        buff_np = numpy.array(buff[:width])
        buff_indices = numpy.round(buff_np).astype(numpy.int32)
        
        mapped_colors = numpy.zeros(width, dtype=numpy.uint32)
        max_idx = len(self.pal_np) - 1
        valid_mask = (buff_indices >= 0) & (buff_indices <= max_idx)
        
        valid_indices = buff_indices[valid_mask]
        mapped_colors[valid_mask] = self.pal_np[valid_indices]
        
        # Use tolist() to prevent Mac Endianness from turning the image black
        self.imagebuffer.extend(mapped_colors.tolist())

        if line == totlines:
            try:
                img = Image.frombytes("RGBX", (int(width), int(totlines)), self.imagebuffer.tobytes())
                self.base_width = int(width)
                self.base_height = int(totlines)
                orig_width = int(width)
                orig_height = int(totlines)

                # --- 1. SANE CAMERA SCALING ---
                scale_factor = 2.0 
                
                new_width = int(orig_width * scale_factor)
                new_height = int(orig_height * scale_factor)

                disp_width = self.display.width
                disp_height = self.display.height

                if new_width > disp_width or new_height > disp_height:
                    width_ratio = float(disp_width) / new_width
                    height_ratio = float(disp_height) / new_height
                    scale_adjustment = min(width_ratio, height_ratio)
                    scale_factor = scale_factor * scale_adjustment
                    new_width = int(orig_width * scale_factor)
                    new_height = int(orig_height * scale_factor)

                # --- 2. CPU-FRIENDLY RESIZE ---
                img_resized = img.resize((new_width, new_height), Image.NEAREST)

                # --- 3. BULLETPROOF TEXT BURN-IN ---
                padded_height = new_height + 40
                final_img = Image.new("RGB", (new_width, padded_height), (128, 128, 128))
                final_img.paste(img_resized, (0, 0))
                
                draw = ImageDraw.Draw(final_img)
                text_x = 10 
                text_y = new_height + 10
                draw.text((text_x, text_y), self._img_title_, fill=(255, 255, 255))

                # --- NEW: Save raw camera dimensions for the overlay math! ---
                self.cam_physical_width = new_width
                self.cam_physical_height = new_height
                self.cam_padded_height = padded_height
                
                self.display_width = new_width
                self.display_height = padded_height
                # -------------------------------------------------------------

                self.__img__ = ImageDraw.Draw(final_img)
                self.draw_cross_hair()
                
                # --- 4. INSTANT BMP SAVE & DISPLAY ---
                final_img.save(self.cam_img)
                self.display.clear()
                
                # Since the image and text are now one single file, we just draw it!
                self.display.image(self.cam_img, True, x=0, y=0)
                
                self.draw_mouse_crosshair()
                self.display.show()

            except Exception as e:
                print(f"DEBUG ERROR: Error in image drawing after buffer conversion/display: {e}")

            self.imagebuffer = array.array(self.buffer_type)

    def draw_mouse_crosshair(self):
        '''Draws a crosshair at the mouse cursor position on the canvas'''
        try:
            pos, timestamp = self.mouse.get_pos()
            x, y = pos

        except Exception as e:
            print(f"DEBUG ERROR: Could not draw mouse crosshair: {e}")

    def set_image_palette(self, r, g, b):
        self.imagebuffer = array.array(self.buffer_type)
        sz = len(r)
        i = 0
        self.pal = []
        while i < sz:
            rf = int(b[i]) 
            gf = int(g[i]) 
            bf = int(r[i]) 
            self.pal.append((rf << 16) | (gf << 8) | (bf))
            i = i+1
            
        # Add this line so our fast vector loop can map colors instantly
        self.pal_np = numpy.array(self.pal, dtype=numpy.uint32)