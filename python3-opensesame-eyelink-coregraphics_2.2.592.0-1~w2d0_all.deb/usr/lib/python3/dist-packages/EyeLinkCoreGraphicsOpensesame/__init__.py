import importlib.metadata
__version__ = importlib.metadata.version("opensesame-eyelink-coregraphics")
_last_updated = '13/04/2026'

from .EyeLinkCoreGraphicsOpensesame import EyeLinkCoreGraphicsOpensesame
