# Copyright (C) 2013-2022 Wilbert van Ham, Radboud University Nijmegen
# Distributed under the terms of the GNU General Public License (GPL).

#version info for RuSocSci
__version__='0.9.2'
__license__='GNU GPLv3 (or more recent equivalent)'
__author__='Wilbert van Ham'
__author_email__='wilbert.vanham@ru.nl'
__maintainer_email__='wilbert.vanham@ru.nl'
__url__='https://www.socsci.ru.nl/wilberth/python/rusocsci.html'



